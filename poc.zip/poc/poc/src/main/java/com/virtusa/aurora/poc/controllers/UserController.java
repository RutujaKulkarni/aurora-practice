package com.virtusa.aurora.poc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.aurora.poc.models.User;
import com.virtusa.aurora.poc.repositories.UserRepository;

@RestController
public class UserController {
	
	@Autowired
	private UserRepository userrepo;
	
	@GetMapping("/users")
	public List<User> getUsers(){
		return (List<User>) userrepo.findAll();
	}

		
	@PostMapping(value = "/users", consumes = "application/json", produces = "application/json")
	public void addUser(@RequestBody User user) {
		userrepo.save(user);
	}
}
